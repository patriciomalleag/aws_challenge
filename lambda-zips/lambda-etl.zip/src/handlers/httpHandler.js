/**
 * Manejador HTTP para la función Lambda ETL
 * @module lambda-etl/handlers/httpHandler
 */

const { logger, logError, logPerformance } = require('../../../shared/utils/logger');
const { createError } = require('../../../shared/constants/errorCodes');
const { isAllowedMimeType, isValidFileSize } = require('../../../shared/constants/fileTypes');
const CsvProcessor = require('../services/csvProcessor');
const CatalogService = require('../services/catalogService');
const S3Utils = require('../utils/s3Utils');
const FileUtils = require('../utils/fileUtils');

/**
 * Inicializar servicios
 */
exports.initialize = async () => {
  try {
    logger.info('HTTP Handler ETL inicializado correctamente');
  } catch (error) {
    logger.error('Error inicializando HTTP Handler ETL', { error: error.message });
    throw error;
  }
};

/**
 * Limpiar recursos
 */
exports.cleanup = async () => {
  try {
    logger.info('HTTP Handler ETL limpiado correctamente');
  } catch (error) {
    logger.error('Error limpiando HTTP Handler ETL', { error: error.message });
  }
};

/**
 * Manejar request de procesamiento ETL
 * @param {Object} event - Evento HTTP
 * @param {Object} context - Contexto Lambda
 * @returns {Object} - Respuesta HTTP
 */
exports.handleProcessRequest = async (event, context) => {
  console.log('========== HTTP HANDLER PROCESS REQUEST ==========');
  console.log('Event recibido en handleProcessRequest:', JSON.stringify(event, null, 2));
  
  const startTime = Date.now();
  const requestId = context.awsRequestId;

  try {
    console.log('Parseando body del evento...');
    console.log('Event body raw:', event.body);
    // Parsear body del request
    const body = JSON.parse(event.body || '{}');
    console.log('Body parseado:', JSON.stringify(body, null, 2));
    
    const { fileId, bucketName, objectKey, tableName, directory } = body;

    console.log('Parámetros extraídos:', {
      fileId,
      bucketName,
      objectKey,
      tableName,
      directory
    });

    // Validar parámetros requeridos
    if (!fileId) {
      console.log('ERROR: fileId faltante');
      throw createError('VALIDATION_ERROR', 'fileId es requerido');
    }
    
    if (!bucketName) {
      console.log('ERROR: bucketName faltante');
      throw createError('VALIDATION_ERROR', 'bucketName es requerido');
    }
    
    if (!objectKey) {
      console.log('ERROR: objectKey faltante');
      throw createError('VALIDATION_ERROR', 'objectKey es requerido');
    }

    console.log('Todos los parámetros validados correctamente');

    logger.info('Iniciando procesamiento ETL via HTTP', {
      requestId,
      fileId,
      bucketName,
      objectKey,
      tableName,
      directory
    });

    console.log('Llamando a processFileForETL...');
    // Procesar archivo usando la lógica existente adaptada
    const result = await processFileForETL({
      fileId,
      bucketName,
      objectKey,
      tableName,
      directory
    }, context);
    
    console.log('Resultado de processFileForETL:', result);
    
    const processingTime = Date.now() - startTime;
    
    logPerformance('ETL_HTTP_PROCESSING', processingTime, {
      requestId,
      fileId,
      tableName,
      originalSize: result.originalSize,
      rowCount: result.rowCount
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: true,
        data: {
          fileId: result.fileId,
          tableName: result.tableName,
          processingTime: processingTime,
          originalSize: result.originalSize,
          rowCount: result.rowCount,
          columnCount: result.columnCount,
          status: result.status
        },
        requestId
      })
    };

  } catch (error) {
    const processingTime = Date.now() - startTime;
    
    logError(error, {
      requestId,
      processingTime,
      body: event.body
    }, 'httpHandler-etl');

    return {
      statusCode: error.statusCode || 500,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Error interno del servidor',
        code: error.code || 'INTERNAL_ERROR',
        requestId,
        timestamp: new Date().toISOString()
      })
    };
  }
};

/**
 * Procesar archivo para ETL - Lógica adaptada de s3EventHandler
 * @param {Object} params - Parámetros del archivo
 * @param {Object} context - Contexto Lambda
 * @returns {Object} - Resultado del procesamiento
 */
const processFileForETL = async (params, context) => {
  console.log('========== PROCESS FILE FOR ETL ==========');
  console.log('Parámetros recibidos:', JSON.stringify(params, null, 2));
  
  const startTime = Date.now();
  const requestId = context.awsRequestId;
  const { fileId, bucketName, objectKey, tableName, directory } = params;

  logger.info('Procesando archivo para ETL', {
    requestId,
    fileId,
    bucketName,
    objectKey,
    tableName,
    directory
  });

  try {
    console.log('Validando bucket...');
    // 1. Validar que el bucket sea el correcto
    const expectedRawBucket = process.env.S3_BUCKET_RAW;
    console.log('Bucket esperado:', expectedRawBucket);
    console.log('Bucket recibido:', bucketName);
    
    if (bucketName !== expectedRawBucket) {
      console.log('ERROR: Bucket incorrecto');
      throw createError('VALIDATION_ERROR', 
        `Bucket incorrecto: ${bucketName}. Se esperaba: ${expectedRawBucket}`);
    }

    console.log('Verificando tipo de archivo...');
    // 2. Solo procesar archivos CSV, no esquemas JSON
    if (objectKey.endsWith('.json')) {
      console.log('Ignorando archivo JSON (esquema):', objectKey);
      logger.info('Ignorando archivo JSON (esquema)', {
        requestId,
        objectKey
      });
      return {
        skipped: true,
        reason: 'JSON schema file',
        objectKey
      };
    }

    console.log('Obteniendo metadatos del objeto S3...');
    // 3. Obtener metadatos del objeto S3
    const objectMetadata = await S3Utils.getObjectMetadata(bucketName, objectKey);
    console.log('Metadatos obtenidos:', objectMetadata);
    
    logger.info('Metadatos del objeto obtenidos', {
      requestId,
      contentType: objectMetadata.ContentType,
      contentLength: objectMetadata.ContentLength,
      lastModified: objectMetadata.LastModified,
      metadata: objectMetadata.Metadata
    });

    // 4. Extraer información de metadatos (con fallbacks de parámetros HTTP)
    const metaTableName = objectMetadata.Metadata['table-name'] || tableName;
    const metaDirectory = objectMetadata.Metadata['directory'] || directory;
    const metaFileId = objectMetadata.Metadata['file-id'] || fileId;
    const separator = objectMetadata.Metadata['separator'] || ',';

    if (!metaTableName || !metaDirectory || !metaFileId) {
      throw createError('VALIDATION_ERROR', 
        'Información incompleta: faltan table-name, directory o file-id');
    }

    // 5. Validar tipo y tamaño del archivo
    if (!isAllowedMimeType(objectMetadata.ContentType)) {
      throw createError('INVALID_FILE_TYPE', 
        `Tipo de archivo no permitido: ${objectMetadata.ContentType}`);
    }

    if (!isValidFileSize(objectMetadata.ContentLength, objectMetadata.ContentType)) {
      throw createError('INVALID_FILE_SIZE', 
        `Tamaño de archivo excede el límite: ${objectMetadata.ContentLength} bytes`);
    }

    // 6. Descargar archivo CSV temporalmente
    const tempCsvPath = await S3Utils.downloadObject(bucketName, objectKey);
    
    logger.info('Archivo CSV descargado temporalmente', {
      requestId,
      tempCsvPath,
      fileSize: objectMetadata.ContentLength
    });

    // 7. Descargar esquema JSON correspondiente
    const schemaKey = objectKey.replace(/\/[^\/]+\.csv$/, '/schema.json');
    let schema;
    
    try {
      const tempSchemaPath = await S3Utils.downloadObject(bucketName, schemaKey);
      const schemaContent = await FileUtils.readFile(tempSchemaPath);
      schema = JSON.parse(schemaContent);
      
      logger.info('Esquema JSON descargado', {
        requestId,
        schemaKey,
        schemaFields: schema.schema.length
      });

      // Limpiar archivo temporal del esquema
      await FileUtils.cleanupTempFiles([tempSchemaPath]);
    } catch (schemaError) {
      logger.warn('No se pudo obtener el esquema JSON, generando automáticamente', {
        requestId,
        schemaKey,
        error: schemaError.message
      });
      
      // Generar esquema automáticamente si no existe
      const csvProcessingResult = await CsvProcessor.processCsvFile(tempCsvPath, objectKey);
      schema = {
        tableName: metaTableName,
        directory: metaDirectory,
        schema: csvProcessingResult.schema,
        fileId: metaFileId
      };
    }

      try {
      console.log('[ETL] Iniciando procesamiento CSV con esquema...');
      // 8. Procesar archivo CSV con el esquema
      const csvProcessingResult = await CsvProcessor.processCsvFileWithSchema(
        tempCsvPath, 
        objectKey, 
        schema.schema,
        separator
      );
      console.log('[ETL] Procesamiento CSV completado:', {
        rowCount: csvProcessingResult.rowCount,
        columnCount: csvProcessingResult.columnCount
      });
      
      logger.info('Archivo CSV procesado con esquema', {
        requestId,
        rowCount: csvProcessingResult.rowCount,
        columnCount: csvProcessingResult.columnCount,
        schema: csvProcessingResult.schema
      });

      console.log('[ETL] Iniciando actualización de catálogo en DynamoDB...');
      const catalogEntry = await CatalogService.updateCatalogEntry({
        fileId: metaFileId,
        tableName: metaTableName,
        directory: metaDirectory,
        originalFileName: objectMetadata.Metadata['original-name'],
        originalFileSize: objectMetadata.ContentLength,
        schema: schema.schema,
        rowCount: csvProcessingResult.rowCount,
        columnCount: csvProcessingResult.columnCount,
        s3Location: {
          rawBucket: bucketName,
          rawKey: objectKey
        },
        processingMetadata: {
          processingTime: Date.now() - startTime,
          requestId,
          lambdaMemorySize: context.memoryLimitInMB,
          lambdaTimeout: context.getRemainingTimeInMillis(),
          separator: separator
        }
      });
      
      console.log('[ETL] Catálogo actualizado exitosamente en DynamoDB');      logger.info('Dataset actualizado en DynamoDB', {
        requestId,
        fileId: metaFileId,
        tableName: metaTableName,
        status: 'processed'
      });

      // 10. Limpiar archivos temporales
      await FileUtils.cleanupTempFiles([tempCsvPath]);

      const totalProcessingTime = Date.now() - startTime;
      
      logger.info('Procesamiento ETL completado exitosamente', {
        requestId,
        fileId: metaFileId,
        tableName: metaTableName,
        totalProcessingTime,
        originalSize: objectMetadata.ContentLength
      });

      return {
        fileId: metaFileId,
        tableName: metaTableName,
        processingTime: totalProcessingTime,
        originalSize: objectMetadata.ContentLength,
        rowCount: csvProcessingResult.rowCount,
        columnCount: csvProcessingResult.columnCount,
        status: 'processed'
      };

    } catch (processingError) {
      // Limpiar archivos temporales en caso de error
      await FileUtils.cleanupTempFiles([tempCsvPath]);
      
      // Actualizar estado en DynamoDB como error
      await CatalogService.updateProcessingStatus(metaFileId, 'error', {
        error: processingError.message,
        requestId,
        processingTime: Date.now() - startTime
      });
      
      throw processingError;
    }

  } catch (error) {
    const processingTime = Date.now() - startTime;
    
    logError(error, {
      requestId,
      fileId,
      bucketName,
      objectKey,
      processingTime
    }, 'etl-http-processing');

    // Re-lanzar el error para que el manejador principal lo capture
    throw error;
  }
};

/**
 * Manejar health check
 * @param {Object} event - Evento HTTP
 * @param {Object} context - Contexto Lambda
 * @returns {Object} - Respuesta HTTP
 */
exports.handleHealthCheck = async (event, context) => {
  const requestId = context.awsRequestId;

  try {
    // Verificar variables de entorno requeridas
    const requiredEnvVars = [
      'S3_BUCKET_RAW',
      'DDB_TABLE_NAME'
    ];

    const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
    
    const healthStatus = {
      status: missingVars.length === 0 ? 'healthy' : 'unhealthy',
      timestamp: new Date().toISOString(),
      requestId,
      environment: {
        missingVars: missingVars.length > 0 ? missingVars : undefined,
        buckets: {
          raw: process.env.S3_BUCKET_RAW
        },
        dynamodb: process.env.DDB_TABLE_NAME
      }
    };

    return {
      statusCode: missingVars.length === 0 ? 200 : 503,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(healthStatus)
    };

  } catch (error) {
    logError(error, {
      requestId
    }, 'httpHandler-etl');

    return {
      statusCode: 503,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        status: 'unhealthy',
        error: error.message,
        timestamp: new Date().toISOString(),
        requestId
      })
    };
  }
};